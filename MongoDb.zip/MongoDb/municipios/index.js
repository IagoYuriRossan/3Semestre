const { MongoClient } = require('mongodb')
const fs = require('fs')

const url = 'mongodb://localhost:27017'
const dbName = 'estoque'
const collectionName = 'municipios'

async function importMunicipios(){
    const client = new MongoClient(url)
    try {
        await client.connect()
        console.log('✔ Conectado ao MongoDB')
        const dados = fs.readFileSync('municipios.json','utf-8')
        const municipios = JSON.parse(dados)
        //Verificar se é um array
        if(!Array.isArray(municipios)){throw new Error('O JSON deve conter um array de ojetos')}
        //inserir os dados no mongoDB
        const db = client.db(dbName)
        const collection = db.collection(collectionName)
        //Dropar a colletion se existir
        const collections = await db.listCollections({name: collectionName}).toArray()
        if(collections.length>0){
            await collection.drop()
            console.log(` coleção ${collectionName} foi dropada`)
        }
        const resultado = await collection.insertMany
        (municipios)

        console.log(`${resultado.insertedCount} documentos inseridos`)
    } catch(error){
        console.error('❌ Erro ao importar', error.message)
    } finally{
        await client.close() //fecha a conexao
    }
}

importMunicipios()
